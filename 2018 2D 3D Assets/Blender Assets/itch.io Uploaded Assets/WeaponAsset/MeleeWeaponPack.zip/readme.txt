thank you for downloading this low poly melee weapon pack!
check out my low poly forest pack: https://datguyjack.itch.io/lowpolyforestpack
and my low poly rifle pack: https://datguyjack.itch.io/low-poly-rifle-pack

more will come in the future!