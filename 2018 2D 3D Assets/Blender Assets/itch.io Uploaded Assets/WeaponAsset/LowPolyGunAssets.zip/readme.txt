thank you for downloading this low poly rifle pack!
check out my low poly forest pack: https://datguyjack.itch.io/lowpolyforestpack

more will come in the future!